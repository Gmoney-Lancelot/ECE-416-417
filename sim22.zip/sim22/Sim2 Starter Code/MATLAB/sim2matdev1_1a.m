% Constants
T = 300; % Temperature in Kelvin
k = 8.617333262145e-5; % Boltzmann constant in eV/K
q = 1.602176634e-19; % Elementary charge in coulombs

% Doping profiles for part a)
NA_values = [1e19, 1e17, 1e16, 7e15];
ND_values = [7e15, 6e16, 7e17, 1e19];

% Initialize arrays to store results
I0_values = zeros(size(NA_values));
Cj0_values = zeros(size(NA_values));
Cj_minus_4V_values = zeros(size(NA_values));
Vbi_values = zeros(size(NA_values));

% Calculate and store values for each doping profile
for i = 1:length(NA_values)
    NA = NA_values(i);
    ND = ND_values(i);

    % Calculate thermal voltage
    kT_q = k * T / q;

    % Calculate reverse saturation current I0
    I0 = q * ni^2 * ((1 / ND) + (1 / NA)) * (Lp + Ln) / (Lp * Ln);

    % Calculate zero-bias junction capacitance Cj0
    Cj0 = sqrt(q * ni * epsilon_r / (2 * (NA + ND) * (kT_q + Vt) * (1 / NA + 1 / ND)));

    % Calculate junction capacitance at -4V bias (4V reverse bias) Cj, -4V
    V_reverse_bias = -4;
    Cj_minus_4V = sqrt(q * ni * epsilon_r / (2 * (NA + ND) * (kT_q + V_reverse_bias) * (1 / NA + 1 / ND)));

    % Calculate built-in voltage Vbi
    Vbi = kT_q * log(NA * ND / ni^2);

    % Store values in arrays
    I0_values(i) = I0;
    Cj0_values(i) = Cj0;
    Cj_minus_4V_values(i) = Cj_minus_4V;
    Vbi_values(i) = Vbi;
end

% Display the results in a table
table_results = table(NA_values', ND_values', I0_values', Cj0_values', Cj_minus_4V_values', Vbi_values', ...
    'VariableNames', {'NA', 'ND', 'I0', 'Cj0', 'Cj_minus_4V', 'Vbi'});

disp('Results for Part (a):');
disp(table_results);
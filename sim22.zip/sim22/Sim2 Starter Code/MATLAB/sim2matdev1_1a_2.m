% Given constants
q = 1.602176634e-19; % Elementary charge in coulombs
epsilon_0 = 8.854187817e-12; % Permittivity of free space in F/m
ni = 1.5e10; % Intrinsic carrier concentration for GaAs
Vt = (0.0259 * 300) / 300; % Thermal voltage at 300 K

% Minority carrier lifetime
tau_p = 15e-6; % in seconds

% Dimensions
W = 1.5e-6; % Width in meters
L = 2e-6; % Length in meters
D = 3e-6; % Depth in meters

% Doping profiles
NA1 = 1e19;
ND1 = 7e15;

NA2 = 1e17;
ND2 = 6e16;

NA3 = 1e16;
ND3 = 7e17;

NA4 = 7e15;
ND4 = 1e19;

% Function to calculate mobility
mu_n = @(ND) 500 + 8900 ./ (1 + ND / (6e16)).^0.394;
mu_p = @(NA) 20 + 471.5 ./ (1 + NA / (1.48e17)).^0.38;

% Function to calculate built-in voltage (Vbi)
Vbi = @(NA, ND) (Vt * log((NA * ND) / (ni^2))) / 2;

% Function to calculate reverse saturation current (I0)
I0 = @(NA, ND) q * (mu_n(ND) * ND + mu_p(NA) * NA) * (W * L) / tau_p;

% Function to calculate zero-bias junction capacitance (Cj0)
Cj0 = @(NA, ND) sqrt((q * epsilon_0 * mu_n(ND) * ND + q * epsilon_0 * mu_p(NA) * NA) / (2 * abs(Vbi(NA, ND))));

% Function to calculate junction capacitance at -4V bias (Cj, -4V)
Cj_minus4V = @(NA, ND) Cj0(NA, ND) / sqrt(1 - (-4 / Vbi(NA, ND)));

% Create a cell array to store the results
results = cell(4, 5);

% Calculate and fill in the cell array
for i = 1:4
    NA_val = eval(['NA', num2str(i)]);
    ND_val = eval(['ND', num2str(i)]);
    
    I0_val = I0(NA_val, ND_val);
    Cj0_val = Cj0(NA_val, ND_val);
    Cj_minus4V_val = Cj_minus4V(NA_val, ND_val);
    Vbi_val = Vbi(NA_val, ND_val);
    
    % Fill in the cell array
    results{i, 1} = i;
    results{i, 2} = I0_val;
    results{i, 3} = Cj0_val;
    results{i, 4} = Cj_minus4V_val;
    results{i, 5} = Vbi_val;
end

% Create a table from the cell array
resultsTable = cell2table(results, 'VariableNames', {'Profile', 'I0 (A)', 'Cj0 (F)', 'Cj, -4V (F)', 'Vbi (V)'});

% Display the table
disp(resultsTable);


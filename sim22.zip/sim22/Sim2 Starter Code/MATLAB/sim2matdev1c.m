% Given data for doping scenario iii)
I_s = 1.65E-17;
n = 1;
Vt = 0.0259; % Thermal voltage at room temperature

% Voltage range from -2V to 2V
V = linspace(-2, 2, 100);

% Minority carrier lifetimes (in seconds)
tau_15us = 15e-6;
tau_150us = 150e-6;

% Calculate current (I) for both lifetimes
I_15us = I_s * (exp(V / (n * Vt * tau_15us)) - 1);
I_150us = I_s * (exp(V / (n * Vt * tau_150us)) - 1);

% Plotting I-V curves
figure;
plot(V, I_15us, '-o', 'DisplayName', '15 μs');
hold on;
plot(V, I_150us, '-s', 'DisplayName', '150 μs');

% Labeling
xlabel('Voltage (V)');
ylabel('Current (A)');
title('I-V Curve for Doping Scenario iii)');
legend('Location', 'Best');
grid on;

% Display positive and negative voltages
xticks([-2 -1 0 1 2]);
xticklabels({'-2V', '-1V', '0V', '1V', '2V'});

hold off;
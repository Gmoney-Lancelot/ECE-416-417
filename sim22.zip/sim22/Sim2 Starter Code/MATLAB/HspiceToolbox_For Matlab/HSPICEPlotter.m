% Extract spice results from .sw0 (or .tr0) file into a structure "x"
x = loadsig('hspice_StarterCode_2023.sw0');

% Extract diode current 'i_d1' from structure 'x'
i = evalsig(x, 'i_d1');
% Use lssig(x) to list possible signals

% Extract applied voltage at node n1 into variable "v"
v = evalsig(x, 'v_n1');

% Plot I-V curve (flipped horizontally)
figure;
plot(flip(v), i);
xlabel('Applied Voltage (V_A) [V]');
ylabel('Current [A]');
title('Horizontally I-V Curve');
grid on;

% Plot I-V curve with a logarithmic scale on the y-axis (flipped horizontally)
figure;
semilogy(flip(v), abs(i));
xlabel('Applied Voltage (V_A) [V]');
ylabel('Current [A]');
title('Horizontally I-V Curve (Logarithmic Scale)');
grid on;
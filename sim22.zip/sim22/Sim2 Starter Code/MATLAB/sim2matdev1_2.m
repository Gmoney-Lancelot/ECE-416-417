% Constants
T = 300; % Temperature in Kelvin
q = 1.6*10^-19; % Elementary charge in C
epsilon_0 = 8.85*10^-14; % Permittivity of free space in F/m

% Given parameters
W = 1.5e-6; % Width of the junction in meters
L = 2e-6; % Length of the junction in meters
D = 3e-6; % Depth of the junction in meters
tau_p = 15e-6; % Minority carrier lifetime in seconds
tau_p_long = 150e-6; % Minority carrier lifetime for part d


% Grading constant for linearly graded junction
alpha = 1e27; % in cm^-4

% Doping profiles
NA1 = 1e19; ND1 = 7e15;
NA2 = 1e17; ND2 = 6e16;
NA3 = 1e16; ND3 = 7e17;
NA4 = 7e15; ND4 = 1e19;

% Mobility equations
mu_n = @(ND) 500 + (8900 ./ (1 + ND / (6e16))).^0.394;
mu_p = @(NA) 20 + (471.5 ./ (1 + NA / (1.48e17))).^0.38;


% Part a: Calculate I0, Cj0, Cj at -4V, Vbi for each profile
ni = 1.5e10; % Intrinsic carrier concentration for GaAs

Vbi = @(NA, ND) (kT_q() / q) * log((NA + sqrt(NA^2 + 4 * ni^2)) / (2 * ni));
I0 = @(NA, ND) q * (mu_n(ND) * ND + mu_p(NA) * NA) * (W * L) / tau_p;
Cj0 = @(NA, ND) sqrt((q * epsilon_0 * mu_n(ND) * ND + q * epsilon_0 * mu_p(NA) * NA) / (2 * abs(Vbi(NA, ND))));
Cj_minus4V = @(NA, ND, V) Cj0(NA, ND) / sqrt(1 - V / Vbi(NA, ND));  % Corrected

% Values in CSV format
fprintf('Profile, I0 (A), Cj0 (F), Cj at -4V (F), Vbi (V)\n');

for i = 1:4
    NA_val = eval(['NA', num2str(i)]);
    ND_val = eval(['ND', num2str(i)]);
    
    I0_val = I0(NA_val, ND_val);
    Cj0_val = Cj0(NA_val, ND_val);
    Cj_minus4V_val = Cj_minus4V(NA_val, ND_val, -4);  % Corrected
    Vbi_val = Vbi(NA_val, ND_val);
    
    fprintf('Profile %d, %.4e, %.4e, %.4e, %.4f\n', i, I0_val, Cj0_val, Cj_minus4V_val, Vbi_val);
end


% Part b: Create log(|I|)-V curves with continuous lines
V_continuous = linspace(-2, 2, 1000);
I_continuous = zeros(4, length(V_continuous));

for i = 1:4
    I_continuous(i, :) = -I0(eval(['NA', num2str(i)]), eval(['ND', num2str(i)])) * (exp(-q * V_continuous / kT_q()) - 1);
end

figure;
semilogy(V_continuous, abs(I_continuous(1, :)), '-', 'DisplayName', 'Profile (i)');
hold on;
semilogy(V_continuous, abs(I_continuous(2, :)), '-', 'DisplayName', 'Profile (ii)');
semilogy(V_continuous, abs(I_continuous(3, :)), '-', 'DisplayName', 'Profile (iii)');
semilogy(V_continuous, abs(I_continuous(4, :)), '-', 'DisplayName', 'Profile (iv)');
xlabel('Voltage (V)');
ylabel('Current (A)');
title('Log(|I|)-V Curves for Different Doping Profiles');
legend('Location', 'Best');
grid on;
set(gca, 'XDir', 'reverse');  % Reverse x-axis direction
hold off;

% Part d: Compute I-V curve for doping profile iii) with 150 μs minority carrier lifetime
V_continuous_d = linspace(2, -2, 1000); % Reverse the voltage range

I_long_continuous = -I0(NA3, ND3) * (exp(-q * V_continuous_d / (kT_q() * tau_p_long)) - 1);

figure;
semilogy(V_continuous_d, abs(I_long_continuous), '-', 'DisplayName', 'Profile (iii) - 150 μs');
hold on;
semilogy(V_continuous, abs(I_continuous(3, :)), '-', 'DisplayName', 'Profile (iii) - 15 μs');
xlabel('Voltage (V)');
ylabel('Current (A)');
title('I-V Curve for Doping Profile (iii) with Different Minority Carrier Lifetimes');
legend('Location', 'Best');
grid on;
set(gca, 'XDir', 'reverse');  % Reverse x-axis direction
hold off;

% Helper function for kT/q
function result = kT_q()
    result = (8.617333262145e-5) * 300. / 1.6*10^-19;
end
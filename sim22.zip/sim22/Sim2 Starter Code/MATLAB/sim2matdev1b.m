% Provided data
data = [
    6.14E-18	3.38E-22	1.43E-22	0.8676504521
    3.72E-18	8.12E-22	3.32E-22	0.803775322
    1.65E-17	4.16E-22	1.70E-22	0.8077832397
    1.81E-17	3.38E-22	1.43E-22	0.8676504521
];

% Voltage range from -2V to 2V
V = linspace(-2, 2, 100);

% Calculate current (I) for each doping profile and voltage
I = zeros(size(data, 1), numel(V));
for i = 1:size(data, 1)
    I(i, :) = data(i, 1) * exp(data(i, 2) * V) - data(i, 3) * exp(-data(i, 4) * V);
end

% Take the absolute value of the current for log plot
I_abs = abs(I);

% Plotting log(|I|)-V curves
figure;
semilogy(V, I_abs(1, :), '-o', 'DisplayName', 'i');
hold on;
semilogy(V, I_abs(2, :), '-s', 'DisplayName', 'ii');
semilogy(V, I_abs(3, :), '-d', 'DisplayName', 'iii');
semilogy(V, I_abs(4, :), '-^', 'DisplayName', 'iv');

% Labeling
xlabel('Voltage (V)');
ylabel('log(|I|)');
title('Log(|I|) vs Voltage');
legend('Location', 'Best');
grid on;

% Display positive and negative voltages
xticks([-2 -1 0 1 2]);
xticklabels({'-2V', '-1V', '0V', '1V', '2V'});

% Add a zero line for reference
hline = refline([0 0]);
hline.Color = 'k';
hline.LineStyle = '--';

hold off;
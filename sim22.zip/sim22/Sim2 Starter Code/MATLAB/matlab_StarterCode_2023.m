
% Starter Code for Simulation Assignment #2
% Created by Michael Hayes 

% Note:  Some values below will need to be filled in.


clear all;
close all;
%Constants
Na = [];                 %p-side doping (in cm^-3)
Nd = []; 				   %n-side doping (in cm^-3)
A = ;                         %Area (in cm2)   
T = 300;                                       %Temperature (K)
Tau = 15*10^-6;                                %Minority carrier lifetime (sec)
M = 0.5;                   
ni = ;                                    %Intrinsic carrier conc (cm^-3)
Kge = 16.2;
e0 = 8.85*10^-14;                              %Permittivity of free space (F/cm)
q = 1.6*10^-19;                                % C
V_bias = -5;                                   %Bias voltage


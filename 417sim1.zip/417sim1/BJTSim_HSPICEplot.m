% Load results from HSPICE
x = loadsig('BJTSim_HSPICE.sw0');   % Change "netlist" to the appropriate name

% Assign different signals to variables
% (Use lssig(x) to list possible signals)
y = evalsig(x, 'i_vce');
w = evalsig(x, 'i_vbe');
% For some reason I can't get the current to show correctly, so I have to
% invert it here (reversing the diode and/or source doesn't work)
y = -y; 
w = -w;
V = evalsig(x, 'VOLTS');

% Plot results
plot(V,y,V,w)